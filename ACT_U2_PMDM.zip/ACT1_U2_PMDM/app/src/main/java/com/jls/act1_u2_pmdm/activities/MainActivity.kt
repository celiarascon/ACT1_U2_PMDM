package com.jls.act1_u2_pmdm.activities

import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import com.jls.act1_u2_pmdm.R
import com.jls.act1_u2_pmdm.adapter.ComunidadAdapter
import com.jls.act1_u2_pmdm.databinding.ActivityMainBinding
import com.jls.act1_u2_pmdm.model.ComunidadAutonoma
import com.jls.act1_u2_pmdm.provider.ComunidadProvider

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var listaComunidades: MutableList<ComunidadAutonoma>
    private lateinit var layoutManager: LinearLayoutManager
    private lateinit var adapter: ComunidadAdapter

    private val editarComunidadLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == RESULT_OK) {
                val data = result.data
                val nuevoNombre = data?.getStringExtra("nombreComunidad")
                val posicion = data?.getIntExtra("posicion", -1)
                if (posicion != null && nuevoNombre != null) {
                    listaComunidades[posicion] = ComunidadAutonoma(nuevoNombre, listaComunidades[posicion].bandera)
                    adapter.notifyItemChanged(posicion)
                }
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val toolbar = binding.toolbar
        setSupportActionBar(toolbar)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        listaComunidades = ComunidadProvider.cargarLista().toMutableList()
        layoutManager = LinearLayoutManager(this)
        binding.rvComunidades.layoutManager = layoutManager
        adapter = ComunidadAdapter(listaComunidades)
        binding.rvComunidades.adapter = adapter
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.toolbar_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.recargar -> {
                recargarData()
                true
            }

            R.id.limpiar -> {
                limpiarData()
                true
            }

            else -> super.onOptionsItemSelected(item)
        }
    }

    private fun recargarData() {
        Toast.makeText(this, "Recargando datos...", Toast.LENGTH_SHORT).show()
        val newData = ComunidadProvider.cargarLista()
        adapter.updateData(newData)
    }

    private fun limpiarData() {
        Toast.makeText(this, "Limpiando datos...", Toast.LENGTH_SHORT).show()
        adapter.clearData()
    }

    fun editarComunidad(position: Int) {
        val intent = Intent(this, EditarComunidadActivity::class.java)
        intent.putExtra("nombreComunidad", listaComunidades[position].nombre)
        intent.putExtra("posicion", position)
        editarComunidadLauncher.launch(intent)
    }
}



