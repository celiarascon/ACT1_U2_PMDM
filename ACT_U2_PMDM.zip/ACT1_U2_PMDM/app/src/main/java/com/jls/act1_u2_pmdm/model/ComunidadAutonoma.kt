package com.jls.act1_u2_pmdm.model

data class ComunidadAutonoma(var nombre: String, var bandera: Int)
