package com.jls.act1_u2_pmdm.adapter

import android.app.AlertDialog
import android.view.View
import android.widget.PopupMenu
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import com.jls.act1_u2_pmdm.R
import com.jls.act1_u2_pmdm.databinding.ItemComunidadBinding
import com.jls.act1_u2_pmdm.model.ComunidadAutonoma
import com.squareup.picasso.Picasso

class ComunidadViewHolder(view: View, private val adapter: ComunidadAdapter) :
    RecyclerView.ViewHolder(view) {

    private val binding = ItemComunidadBinding.bind(view)

    init {
        view.setOnClickListener {
            val nombreComunidad = binding.tvNombre.text.toString()
            Toast.makeText(view.context, "Yo soy de $nombreComunidad", Toast.LENGTH_SHORT).show()
        }

        view.setOnLongClickListener {
            val position = adapterPosition
            if (position != RecyclerView.NO_POSITION) {
                val menu = PopupMenu(view.context, view)
                menu.menuInflater.inflate(R.menu.conceptual_menu, menu.menu)

                menu.setOnMenuItemClickListener { item ->
                    when (item.itemId) {
                        R.id.eliminar -> {
                            val builder = AlertDialog.Builder(view.context)
                            builder.setMessage("¿Estás seguro de que deseas eliminar esta comunidad?")
                                .setPositiveButton("Sí") { _, _ ->
                                    adapter.eliminarComunidad(position)
                                    Toast.makeText(
                                        view.context,
                                        "Comunidad eliminada",
                                        Toast.LENGTH_SHORT
                                    ).show()
                                }
                                .setNegativeButton("No", null)
                            builder.create().show()
                            true
                        }

                        R.id.editar -> {
                            adapter.editarComunidad(position, view.context)
                            true
                        }

                        else -> false
                    }
                }
                menu.show()
            }
            true
        }
    }

    fun render(item: ComunidadAutonoma) {
        binding.tvNombre.text = item.nombre
        Picasso.get().load(item.bandera).resize(80, 80).centerInside().into(binding.ivComunidad)
    }
}
