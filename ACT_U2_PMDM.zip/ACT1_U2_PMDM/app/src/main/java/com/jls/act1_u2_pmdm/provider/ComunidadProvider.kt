package com.jls.act1_u2_pmdm.provider

import com.jls.act1_u2_pmdm.R
import com.jls.act1_u2_pmdm.model.ComunidadAutonoma

class ComunidadProvider {
    companion object {
        fun cargarLista(): MutableList<ComunidadAutonoma> {
            return mutableListOf<ComunidadAutonoma>(
                ComunidadAutonoma( "Galicia", R.drawable.galicia),
                ComunidadAutonoma( "Asturias", R.drawable.asturias),
                ComunidadAutonoma( "Cantabria", R.drawable.cantabria),
                ComunidadAutonoma( "País Vasco", R.drawable.pais_vasco),
                ComunidadAutonoma( "Navarra", R.drawable.navarra),
                ComunidadAutonoma("Cataluña", R.drawable.cataluna),
                ComunidadAutonoma( "La Rioja", R.drawable.la_rioja),
                ComunidadAutonoma( "Castilla y León", R.drawable.castilla_leon),
                ComunidadAutonoma( "Madrid", R.drawable.madrid),
                ComunidadAutonoma( "Castilla-La Mancha", R.drawable.castilla_la_mancha),
                ComunidadAutonoma( "Extremadura", R.drawable.extremadura),
                ComunidadAutonoma( "Andalucía", R.drawable.andalucia),
                ComunidadAutonoma("Murcia", R.drawable.murcia),
                ComunidadAutonoma("Valencia", R.drawable.valencia),
                ComunidadAutonoma( "Islas Baleares", R.drawable.baleares),
                ComunidadAutonoma( "Islas Canarias", R.drawable.canarias),
                ComunidadAutonoma( "Aragón", R.drawable.aragon)
            )
        }
    }
}