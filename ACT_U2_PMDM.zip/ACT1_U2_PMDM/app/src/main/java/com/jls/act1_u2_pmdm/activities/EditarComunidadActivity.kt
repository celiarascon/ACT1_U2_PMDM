package com.jls.act1_u2_pmdm.activities

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.jls.act1_u2_pmdm.databinding.ActivityEditarComunidadBinding
import com.jls.act1_u2_pmdm.model.ComunidadAutonoma
import com.jls.act1_u2_pmdm.provider.ComunidadProvider

class EditarComunidadActivity : AppCompatActivity() {

    private lateinit var binding: ActivityEditarComunidadBinding
    private var posicion: Int = -1
    private var listaComunidades: MutableList<ComunidadAutonoma> = ComunidadProvider.cargarLista()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityEditarComunidadBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val nombreComunidad = intent.getStringExtra("nombreComunidad")
        posicion = intent.getIntExtra("posicion", -1)

        binding.nombreComunidadEditText.setText(nombreComunidad)

        binding.botonGuardar.setOnClickListener {
            val nuevoNombre = binding.nombreComunidadEditText.text.toString()
            if (posicion != -1) {
                val resultIntent = Intent()
                resultIntent.putExtra("nombreComunidad", nuevoNombre)
                resultIntent.putExtra(
                    "posicion",
                    posicion
                )

                setResult(RESULT_OK, resultIntent)
                finish()
            } else {
                Toast.makeText(this, "No se pudo actualizar la comunidad.", Toast.LENGTH_SHORT).show()
            }
        }
    }
}

