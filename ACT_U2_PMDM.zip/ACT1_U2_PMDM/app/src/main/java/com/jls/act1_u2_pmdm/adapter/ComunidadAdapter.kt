package com.jls.act1_u2_pmdm.adapter

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.jls.act1_u2_pmdm.R
import com.jls.act1_u2_pmdm.model.ComunidadAutonoma
import com.jls.act1_u2_pmdm.activities.EditarComunidadActivity

class ComunidadAdapter(
    private val lista: MutableList<ComunidadAutonoma>
) : RecyclerView.Adapter<ComunidadViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ComunidadViewHolder {
        val layoutInflater = LayoutInflater.from(parent.context)
        val view = layoutInflater.inflate(R.layout.item_comunidad, parent, false)
        return ComunidadViewHolder(view, this)
    }

    override fun getItemCount(): Int = lista.size

    override fun onBindViewHolder(holder: ComunidadViewHolder, position: Int) {
        val item = lista[position]
        holder.render(item)
    }

    fun updateData(newList: List<ComunidadAutonoma>) {
        val oldSize = lista.size
        lista.clear()
        notifyItemRangeRemoved(0, oldSize)
        lista.addAll(newList)
        notifyItemRangeInserted(0, newList.size)
    }

    fun clearData() {
        val size = lista.size
        lista.clear()
        notifyItemRangeRemoved(0, size)
    }

    fun eliminarComunidad(position: Int) {
        lista.removeAt(position)
        notifyItemRemoved(position)
    }

    fun editarComunidad(position: Int, context: Context) {
        val intent = Intent(context, EditarComunidadActivity::class.java)
        intent.putExtra("nombreComunidad", lista[position].nombre)
        intent.putExtra("posicion", position)
        context.startActivity(intent)
    }
}

